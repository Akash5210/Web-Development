import React from 'react';

//Title is a child component
function Title(props){
    return <h1>{props.title}</h1>;
}

export default Title